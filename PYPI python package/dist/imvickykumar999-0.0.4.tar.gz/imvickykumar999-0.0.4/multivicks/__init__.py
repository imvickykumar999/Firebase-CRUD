
# when you import package for the first time, this __init__.py file runs automatically.

print('\nWelcome to my website ;) ', 'https://imvickykumar999.herokuapp.com/iotcar')

print('\nUse help(module name) function to know available functions in it.')
